﻿# PLPProjetoOverBooking
Projeto para a disciplina de PLP - UFCG

Sistema de compra de passagens áreas com intuido de evitar Overbooking (compra da mesma passagem por mais de um usuário)
