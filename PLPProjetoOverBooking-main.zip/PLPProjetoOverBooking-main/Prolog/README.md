<h1>Aplicação em PROLOG</h1>

<h2>Para rodar o projeto é necessário que seja executado no terminal os seguintes comandos:</h2>
<ol>
    <li><code>cd Desktop
    <li>git clone https://github.com/amaurineo/PLPProjetoOverBooking.git
    <li>cd Prolog
    <li>swipl -f .\main.pl</code>
</ol>
<p>Link da apresentação em vídeo no <a href="https://www.youtube.com/watch?v=777R4rX9dqY">YouTube</a>.</p>
<p>OBS: Ao realizar cadastros de funcionários é preciso que os nomes sejam escritos todos em minúsculos para evitar bus.</p>